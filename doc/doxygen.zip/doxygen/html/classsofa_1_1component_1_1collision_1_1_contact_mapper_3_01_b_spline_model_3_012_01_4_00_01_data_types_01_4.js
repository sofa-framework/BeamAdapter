var classsofa_1_1component_1_1collision_1_1_contact_mapper_3_01_b_spline_model_3_012_01_4_00_01_data_types_01_4 =
[
    [ "Coord", "classsofa_1_1component_1_1collision_1_1_contact_mapper_3_01_b_spline_model_3_012_01_4_00_01_data_types_01_4.html#a7c0bd56aca42d0e855a400b50f3e078b", null ],
    [ "Real", "classsofa_1_1component_1_1collision_1_1_contact_mapper_3_01_b_spline_model_3_012_01_4_00_01_data_types_01_4.html#acf523069e5b1497cffac17511dcd3b1e", null ]
];