var structsofa_1_1component_1_1mapping_1_1_adaptive_beam_mapping_1_1_pos_point_definition =
[
    [ "baryPoint", "structsofa_1_1component_1_1mapping_1_1_adaptive_beam_mapping_1_1_pos_point_definition.html#a3dbef08fcd245ce9904a53a644922279", null ],
    [ "beamId", "structsofa_1_1component_1_1mapping_1_1_adaptive_beam_mapping_1_1_pos_point_definition.html#ac3e27bd7d049f10f679d623f939ab64e", null ]
];