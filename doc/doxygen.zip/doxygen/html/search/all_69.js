var searchData=
[
  ['implicitsurfaceadaptiveconstraint',['ImplicitSurfaceAdaptiveConstraint',['../classsofa_1_1component_1_1constraint_1_1_implicit_surface_adaptive_constraint.html',1,'sofa::component::constraint']]],
  ['implicitsurfaceadaptiveconstraintresolution',['ImplicitSurfaceAdaptiveConstraintResolution',['../classsofa_1_1component_1_1constraint_1_1_implicit_surface_adaptive_constraint_resolution.html',1,'sofa::component::constraint']]],
  ['implsurfcontact',['ImplSurfContact',['../classsofa_1_1component_1_1constraint_1_1_impl_surf_contact.html',1,'sofa::component::constraint']]],
  ['init',['init',['../classsofa_1_1component_1_1controller_1_1_adaptive_beam_controller.html#a02fd73d861ef2e4aabb38c0c9ff82947',1,'sofa::component::controller::AdaptiveBeamController::init()'],['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html#a02fd73d861ef2e4aabb38c0c9ff82947',1,'sofa::component::controller::InterventionalRadiologyController::init()'],['../classsofa_1_1component_1_1controller_1_1_suture_controller.html#a02fd73d861ef2e4aabb38c0c9ff82947',1,'sofa::component::controller::SutureController::init()']]],
  ['initfromloader',['InitFromLoader',['../classsofa_1_1component_1_1engine_1_1_wire_rest_shape.html#a6184070f77713a13d8c8047af9301a83',1,'sofa::component::engine::WireRestShape']]],
  ['initrestconfig',['InitRestConfig',['../classsofa_1_1component_1_1engine_1_1_wire_rest_shape.html#acf4111cc27e67189d6f67210df29630c',1,'sofa::component::engine::WireRestShape']]],
  ['interpolatepointusingspline',['interpolatePointUsingSpline',['../classsofa_1_1component_1_1fem_1_1_beam_interpolation.html#af4535a8dba9ea2462c30b9dc4014d607',1,'sofa::component::fem::BeamInterpolation']]],
  ['interpolatetransformusingspline',['InterpolateTransformUsingSpline',['../classsofa_1_1component_1_1fem_1_1_beam_interpolation.html#afa932d480a4b7def4c8b3b1bc6dc31e3',1,'sofa::component::fem::BeamInterpolation']]],
  ['interpolation',['interpolation',['../classsofa_1_1component_1_1fem_1_1_projection_search.html#a1643c12c83ceaa91c522174bb970e040',1,'sofa::component::fem::ProjectionSearch']]],
  ['interpolationisalreadyinitialized',['interpolationIsAlreadyInitialized',['../classsofa_1_1component_1_1fem_1_1_beam_interpolation.html#a690b4d68c0517a05ccf9fb9c41c7ac9e',1,'sofa::component::fem::BeamInterpolation']]],
  ['interventionalradiologycontroller',['InterventionalRadiologyController',['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html',1,'sofa::component::controller']]],
  ['interventionalradiologycontroller',['InterventionalRadiologyController',['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html#a177be25cd18629b1def38ce83a0980f6',1,'sofa::component::controller::InterventionalRadiologyController']]],
  ['isholonomic',['isHolonomic',['../classsofa_1_1component_1_1constraint_1_1_implicit_surface_adaptive_constraint.html#a4c4b18d37ed22ee9990a18f718f2592b',1,'sofa::component::constraint::ImplicitSurfaceAdaptiveConstraint']]]
];
