var searchData=
[
  ['rangesampling',['rangeSampling',['../classsofa_1_1component_1_1fem_1_1_projection_search.html#acb7479c8283bf7c6ab9037c6d5447439',1,'sofa::component::fem::ProjectionSearch']]]
];
