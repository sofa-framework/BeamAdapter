var searchData=
[
  ['usecurvabs',['useCurvAbs',['../classsofa_1_1component_1_1mapping_1_1_adaptive_beam_mapping.html#a630ccdc1b760d0fe8ef99cb70fcbba9e',1,'sofa::component::mapping::AdaptiveBeamMapping']]]
];
