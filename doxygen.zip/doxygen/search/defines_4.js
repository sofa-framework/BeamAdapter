var searchData=
[
  ['verif',['VERIF',['../_wire_rest_shape_8inl.html#a1bb678d8f64ab3e184184c736ccd786b',1,'WireRestShape.inl']]]
];
