var searchData=
[
  ['loadmotiondata',['loadMotionData',['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html#af4dd47349f86b46b68e52a125d7a8349',1,'sofa::component::controller::InterventionalRadiologyController']]]
];
