var searchData=
[
  ['wbeaminterpolation',['WBeamInterpolation',['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html#a4498960151db0174f2f668277f7e256e',1,'sofa::component::controller::InterventionalRadiologyController']]]
];
