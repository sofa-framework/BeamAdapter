var searchData=
[
  ['spatialvector',['SpatialVector',['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html#a314bf2bb1e67cb2375ed48afcdd7ee60',1,'sofa::component::controller::InterventionalRadiologyController::SpatialVector()'],['../classsofa_1_1component_1_1mapping_1_1_multi_adaptive_beam_mapping.html#a17f4a7ad0cccb295a4b9cf1166c55e8e',1,'sofa::component::mapping::MultiAdaptiveBeamMapping::SpatialVector()']]]
];
