var searchData=
[
  ['nodecurvabs',['nodeCurvAbs',['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html#a469c404404575dc1f0173d088e5cb3c7',1,'sofa::component::controller::InterventionalRadiologyController']]],
  ['numcontrollednodes',['numControlledNodes',['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html#a10d1b0979d3ddcee8f7816abae9c795b',1,'sofa::component::controller::InterventionalRadiologyController']]]
];
