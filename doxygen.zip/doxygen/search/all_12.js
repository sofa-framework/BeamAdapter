var searchData=
[
  ['usecurvabs',['useCurvAbs',['../classsofa_1_1component_1_1mapping_1_1_multi_adaptive_beam_mapping.html#aab375346a54fcc377b695a804d7b84bb',1,'sofa::component::mapping::MultiAdaptiveBeamMapping']]]
];
