var searchData=
[
  ['bwdinit',['bwdInit',['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html#acdefc83d095bf2800243e4d02e71c0dd',1,'sofa::component::controller::InterventionalRadiologyController::bwdInit()'],['../classsofa_1_1component_1_1mapping_1_1_multi_adaptive_beam_mapping.html#ae501246d692bd4033283724f9b5eea0f',1,'sofa::component::mapping::MultiAdaptiveBeamMapping::bwdInit()']]]
];
