var searchData=
[
  ['deriv',['Deriv',['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html#acb4fba46784e41c86dbd5ce9dc59d1b2',1,'sofa::component::controller::InterventionalRadiologyController::Deriv()'],['../classsofa_1_1component_1_1engine_1_1_steerable_catheter.html#a91ff0d08b46db3861f319559a01da380',1,'sofa::component::engine::SteerableCatheter::Deriv()'],['../classsofa_1_1component_1_1mapping_1_1_multi_adaptive_beam_mapping.html#ae79cf06c561cdf775a42197a1c43514e',1,'sofa::component::mapping::MultiAdaptiveBeamMapping::Deriv()']]]
];
