var searchData=
[
  ['tinterventionalradiologycontroller',['TInterventionalRadiologyController',['../classsofa_1_1component_1_1mapping_1_1_multi_adaptive_beam_mapping.html#a10b6f07eebe1645524c862de000a0ebb',1,'sofa::component::mapping::MultiAdaptiveBeamMapping']]],
  ['transform',['Transform',['../classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html#ab336e91dad2625e30e0d813823a7572a',1,'sofa::component::controller::InterventionalRadiologyController::Transform()'],['../classsofa_1_1component_1_1mapping_1_1_multi_adaptive_beam_mapping.html#a6afb831c58c85755d3f26913cb4e3390',1,'sofa::component::mapping::MultiAdaptiveBeamMapping::Transform()']]]
];
