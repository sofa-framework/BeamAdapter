var namespacesofa_1_1component_1_1controller =
[
    [ "InterventionalRadiologyController", "classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller.html", "classsofa_1_1component_1_1controller_1_1_interventional_radiology_controller" ]
];