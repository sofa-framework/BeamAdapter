var namespacesofa_1_1component_1_1mapping =
[
    [ "MultiAdaptiveBeamMapping", "classsofa_1_1component_1_1mapping_1_1_multi_adaptive_beam_mapping.html", "classsofa_1_1component_1_1mapping_1_1_multi_adaptive_beam_mapping" ]
];