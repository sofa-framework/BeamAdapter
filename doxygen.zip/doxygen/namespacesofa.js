var namespacesofa =
[
    [ "component", "namespacesofa_1_1component.html", "namespacesofa_1_1component" ],
    [ "core", "namespacesofa_1_1core.html", null ]
];